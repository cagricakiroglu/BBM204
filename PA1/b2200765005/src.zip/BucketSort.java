import java.util.*;

public class BucketSort {

	public static int[] sort(int[] array) {
		int numberOfBuckets = (int) Math.sqrt(array.length);
		ArrayList<ArrayList<Integer>> buckets = new ArrayList<>(numberOfBuckets);
		for (int i = 0; i < numberOfBuckets; i++) {
			buckets.add(new ArrayList<>());
		}
		int max = max(array);
		for (int i : array) {
			buckets.get(hash(i, max, numberOfBuckets)).add(i);
		}
		for (ArrayList<Integer> bucket : buckets) {
			Collections.sort(bucket);
		}
		int[] sortedArray = new int[array.length];
		int index = 0;
		for (ArrayList<Integer> bucket : buckets) {
			for (int integer : bucket) {
				sortedArray[index++] = integer;
			}
		}
		return sortedArray;
	}
	
	private static int hash(int i, int max, int numberOfBuckets) {
		return (int) Math.floor(i / max * (numberOfBuckets - 1));
	}

	private static int max(int[] array) {
		int max = array[0];
		for (int i = 1; i < array.length; i++) {
			if (array[i] > max) {
				max = array[i];
			}
		}
		return max;
	}
}