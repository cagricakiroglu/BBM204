public class BinarySearch {
    public static int binarySearch(int[] arr_for_temporary, int target) {
        int low = 0;
        int high = arr_for_temporary.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (arr_for_temporary[mid] == target) {
                return mid;
            } else if (arr_for_temporary[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1; // Element not found
    
}

}