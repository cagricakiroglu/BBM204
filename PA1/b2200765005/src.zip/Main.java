import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;



import java.util.Arrays;

import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;


class Main{

    public static void showAndSaveChart(String title, int[] xAxis, double[][] yAxis, String label_name1 , String label_name2,String label_name3,int a) throws IOException {
        // Create Chart
        XYChart chart;
        if(title == "Search Times"){
             chart = new XYChartBuilder().width(800).height(600).title(title)
                .yAxisTitle("Time in Nanoseconds").xAxisTitle("Input Size").build();
        }
        else{
             chart = new XYChartBuilder().width(800).height(600).title(title)
            .yAxisTitle("Time in Milliseconds").xAxisTitle("Input Size").build();

        }
       
        // Convert x axis to double[]
        double[] doubleX = Arrays.stream(xAxis).asDoubleStream().toArray();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);
        if(a==0){

       
        // Add a plot for a sorting algorithm
        chart.addSeries(label_name1, doubleX, yAxis[0]);
        chart.addSeries(label_name2, doubleX, yAxis[1]);        
        chart.addSeries(label_name3, doubleX, yAxis[2]);
        
    }

    if(a==1){
        chart.addSeries(label_name2, doubleX, yAxis[1]);
        chart.addSeries(label_name3, doubleX, yAxis[2]);  
    }
        // Save the chart as PNG
        BitmapEncoder.saveBitmap(chart, title + ".png", BitmapEncoder.BitmapFormat.PNG);

        // Show the chart
        new SwingWrapper(chart).displayChart();
    }




    public static int[] copy (int[] a, int len){
        int[] b = new int[len];
        for (int i = 0; i < len; i++) {
            b[i] = a[i];
        }
        return b;
    }

    
        public static int[] readCsv(String Comerfile) {
            int[] List_ofDuration = new int[]{};

        try{
            String spliter= ",";
            int i=0 ;
            File file = new File(Comerfile);
            FileReader fr = new FileReader(file);
            BufferedReader br= new BufferedReader(fr);
            String line = " ";
            
            List_ofDuration= new int[251281];
            String[] tempArr;
            br.readLine();

            while((line = br.readLine()) != null){
                tempArr = line.split(spliter);
                List_ofDuration[i]=Integer.parseInt(tempArr[6]);
                i++;
            }
            br.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return List_ofDuration;
            
    }

    public static int[] reverse(int[] a, int n) {
        int[] b = new int[n];
        int j = n;
        for (int i = 0; i < n; i++) {
            b[j - 1] = a[i];
            j--;
        }
        return b;
    }

    public static int SizeOfCsv(String ComerFile){
        int size=0;

        try{
            File file = new File(ComerFile);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = " ";
            
            while((line = br.readLine()) != null){
                size++;
            }
            br.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return size-1;
    }

    



    public static void main(String args[]) throws IOException{ 
      

    String file = args[0];
    int[] ListOfFlow= new int[]{};
    int[] sorted_ListOfFlow= new int[]{};
    int[] reverse_ListOfFlow= new int[]{};
    

    ListOfFlow= readCsv(file);
    int len = ListOfFlow.length;
   
   
    sorted_ListOfFlow= copy(ListOfFlow, len);

    
    Arrays.sort(sorted_ListOfFlow);

   

    reverse_ListOfFlow=reverse(sorted_ListOfFlow,len);

   

    int[] inputs = {512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 251281};
   
    int input_len = inputs.length;

    double[][] FirstOne = new double[3][input_len];
    double[][] SecondOne = new double[3][input_len];
    double[][] ThirdOne = new double[3][input_len];
    double[][] ForthOne = new double[3][input_len];


    int experiment = 1 ;

    for (int i  = 0 ; i < 5; i++){
for(experiment=1 ; experiment < 4 ; experiment++){
 
        
        for  (int j = 0 ; j < input_len ; j ++){
            
            int checker = 0 ;
            double time= 0.0;
            int howmanytimes=10;
            long timeElapsed;
            long start=0;
            long end=0;
            int SizeOfInputs = inputs[j];
            int[] arr_for_temporary= new int[SizeOfInputs];

            
            
            for(int k = 0 ; k <howmanytimes ; k++){
                if(experiment==1){// random hali
                    arr_for_temporary=copy(ListOfFlow, SizeOfInputs);
                  
                } 
                else if(experiment==2){// sorted hali
                    arr_for_temporary=copy(sorted_ListOfFlow, SizeOfInputs);
                   
                   
                    
                } 
                else if(experiment==3){// reverse hali
                    arr_for_temporary=copy(reverse_ListOfFlow, SizeOfInputs);
                   
                }
               

                if(i==0){
                    start = System.nanoTime();
                    Selection.sort(arr_for_temporary);
                    end=System.nanoTime();
                    checker=1;
                }
                else if(i==1){
                    start = System.nanoTime();
                    if(experiment==2){
                        checker=1;
                    }
                    QuickSort.sort(arr_for_temporary);
                    end=System.nanoTime();
                    checker=1;
                }
                else if(i==2){
                    start = System.nanoTime();
                    if(experiment==3){
                        checker=1;
                    }
                    BucketSort.sort(arr_for_temporary);
                    end=System.nanoTime();
                    
                    checker=1;
                }
                else if(i==3 && (experiment ==1 || experiment ==2 )){
                    int index = (int) (Math.random() * arr_for_temporary.length);
                    start = System.nanoTime();
                    LinearSearch.linearSearch(arr_for_temporary, arr_for_temporary[index]);
                    end=System.nanoTime();
                    checker=1;
                    howmanytimes=1000;
                    
                }
                else if(i==4 && experiment == 2){
                    checker=1;
                    int index = (int) (Math.random() * arr_for_temporary.length);
                    start = System.nanoTime();
                    BinarySearch.binarySearch(arr_for_temporary,  arr_for_temporary[index]);
                    end=System.nanoTime();
                    howmanytimes=1000;
                }
                
                  
                

                
                if(i==3 || i==4){

                      timeElapsed   = end - start;

               
                
                }
                else{

                     timeElapsed   = end - start;
                    
                   
                     //timeElapsed = (long) ( timeElapsed / 1_000_000);
                     
                }
                if(timeElapsed != 0.0)
                time += timeElapsed;

                
            }

            if(i==0 || i==1 || i==2){
            time = (long) ( time / 1_000_000);
            }

            
            if (checker ==1 ){
            if(i==0){
              
                if(experiment==1)
                FirstOne[i][j] = time/10;
                if(experiment==2)
                
                SecondOne[i][j] = time/10;
                if(experiment==3)
                ThirdOne[i][j]= time/10;
            }
            if(i==1){
               
                if(experiment==1)
               
                FirstOne[i][j] = time/10;
                if(experiment==2)
               
                SecondOne[i][j] = time/10;
                if(experiment==3)
             
                ThirdOne[i][j]= time/10;
            }
            if(i==2){
                
                if(experiment==1)
                FirstOne[i][j] = time/10;
                if(experiment==2)
                SecondOne[i][j] = time/10;
                if(experiment==3)
                ThirdOne[i][j]= time/10;
            }
            if(i==3 && experiment == 1){
              
                ForthOne[0][j]=time/1000;

            }
            if(i==3 && experiment == 2){
            
                ForthOne[1][j]=time/1000;

            }
            
            if (i==4){
                
                ForthOne[2][j]=time/1000;

            }

        }
        }

    }
}
    System.out.println("random");
    for(int i =0 ; i < FirstOne.length  ; i++ ){
        if(i==0)
            System.out.print("Selection Sort   " );
        if(i==1)
            System.out.print("Quick Sort  ");
        if(i==2)
            System.out.print("Bucket Sort  ");
        for (int j = 0; j < FirstOne[0].length; j++) {
            System.out.printf(String.valueOf(FirstOne[i][j]) + ",  ");
        }
        System.out.println(" ");

    }
    System.out.println(" ");
    System.out.println("Sorted");
    for(int i =0 ; i < SecondOne.length  ; i++ ){
        if(i==0)
            System.out.print("Selection Sort  ");
        if(i==1)
            System.out.print("Quick Sort");
        if(i==2)
            System.out.print("Bucket Sort");
        for (int j = 0; j < SecondOne[0].length; j++) {
            System.out.printf(String.valueOf(SecondOne[i][j]) + ",  ");
        }
        System.out.println(" ");

      
    }
    System.out.println(" ");
    System.out.println("Reverse");

    for(int i =0 ; i < ThirdOne.length  ; i++ ){
        if(i==0)
            System.out.print("Selection Sort");
        if(i==1)
            System.out.print("Quick Sort");
        if(i==2)
            System.out.print("Bucket Sort");
        for (int j = 0; j < ThirdOne[0].length; j++) {
            System.out.printf(String.valueOf(ThirdOne[i][j]) + ",  ");
        }
        System.out.println(" ");


    }

    System.out.println(" ");
   
    System.out.println(" ");

    for(int i =0 ; i < 3  ; i++ ){
        if(i==0)
            System.out.print("Linear Search - Random Data");
        if(i==1)
            System.out.print("Linear Search - Sorted Data");
        if(i==2)
            System.out.print("Binary Search - Sorted Data");
        for (int j = 0; j < ForthOne[0].length; j++) {
            System.out.printf(String.valueOf(ForthOne[i][j]) + ",  ");
        }
        System.out.println(" ");


    }
    int a=0;
    showAndSaveChart("Random Data", inputs, FirstOne,"Selection Sort","Quick Sort","Bucket Sort",0);
    showAndSaveChart("Random Data-Quick VS Bucket", inputs, FirstOne,"Selection Sort","Quick Sort","Bucket Sort",1);
    showAndSaveChart("Sorted Data", inputs, SecondOne,"Selection Sort","Quick Sort","Bucket Sort",0);
    showAndSaveChart("Reversly Sorted Data", inputs, ThirdOne,"Selection Sort","Quick Sort","Bucket Sort",0);
    showAndSaveChart("Search Times", inputs, ForthOne,"Linear Search(Random data)","Linear Search(Sorted data)","Binary search(Sorted Data)",0);




  
    }  




}  