public class LinearSearch {
    public static int linearSearch(int[] arr_for_temporary, int target) {
        for (int i = 0; i < arr_for_temporary.length; i++) {
            if (arr_for_temporary[i] == target) {
                return i;
            }
        }
        return -1; // Element not found
    }

}